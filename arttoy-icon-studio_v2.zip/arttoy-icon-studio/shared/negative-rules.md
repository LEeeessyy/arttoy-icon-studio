# 금지·회피 요소 (Negative Rules)

> 이미지 제작 시 금지하거나 피해야 할 요소의 **단일 출처(Single Source of Truth)**입니다.
> `arttoy-ic-prompt`는 이 파일로 Negative Prompt를 만들고,
> `arttoy-ic-review`는 금지 요소 포함 여부 검수에 사용합니다.
>
> 긍정적인 스타일 정의는 `brand-style-guide.md`를 참조합니다.
> 검수 등급 및 판정 방법은 `review-checklist.md`를 참조합니다.
>
> Version: 1.0

---

## 1. 반드시 금지

### 1.1 금지 요소 적용 원칙

이 항목은 미니어처 아트토이 스타일의 기본 비주얼 스타일과 정체성을 훼손하는 요소를 정의한다.

승인된 예외 없이 필수 금지 요소가 나타난 경우 정상 에셋으로 통과 처리하지 않는다.

금지 요소는 실제 이미지에 나타난 시각적 특성을 기준으로 판단한다.

단순히 프롬프트에 특정 단어가 포함되어 있다는 이유만으로 이미지의 품질을 판단하지 않는다.

### 1.2 실사 및 재질

| 금지 요소 | 영어 키워드 |
|---|---|
| 사진과 같은 실사 표현 | photorealistic |
| 사실적인 표면 질감 | photorealistic texture |
| 거친 표면 | rough texture, rough surface |
| 모래처럼 거친 질감 | gritty surface |
| 노이즈가 많은 재질 | noisy material |
| 사실적인 피부 모공 | skin pores |
| 사실적인 털 표현 | realistic fur |
| 개별 머리카락의 사실적 묘사 | realistic hair strands |
| 사실적인 천의 직조 | fabric weave |
| 오염된 콘크리트 | dirty concrete |
| 사실적인 나뭇결 | realistic wood grain |
| 브러시드 메탈 질감 | brushed metal |
| 크롬 반사 | chrome reflection |
| 과도한 유리 굴절 | excessive glass refraction |

재질의 특징을 단순한 형태와 컬러로 표현하는 것은 허용한다.

실사 표면의 복제가 금지 대상이다.

### 1.3 형태 및 구조 오류

- 왜곡된 메인 오브젝트
- 파손되거나 연결이 비정상적인 구조
- 의도하지 않은 중복 오브젝트
- 메인 오브젝트의 잘림
- 대상 인지를 방해하는 구조적 오류
- 캐릭터의 명백하게 잘못된 신체 구조
- 장소를 다른 장소로 오인하게 만드는 형태 오류

영어 키워드:

distorted shape, broken geometry,
unintended duplicated object, cropped main object,
broken anatomy, extra limbs.

### 1.4 컬러 및 시각적 분위기

- 탁하고 불분명한 컬러
- 대상 인지성을 저하하는 흐린 파스텔
- 과도한 네온 광택
- 어두운 사이버펑크 스타일
- 주요 오브젝트가 구분되지 않는 대비
- 승인되지 않은 지정 컬러 및 심볼 변경

영어 키워드:

muddy colors, washed-out pastel,
harsh neon, dark cyberpunk, poor visual contrast.

밝은 하늘색이나 크림색 등 깨끗한 밝은 컬러 자체는 금지하지 않는다.

### 1.5 텍스트 및 로고

- 무작위 생성 텍스트
- 읽을 수 없는 글자
- 잘못된 철자
- 요청하지 않은 간판
- 허용 범위를 벗어나는 추가 문구
- 승인되지 않은 로고
- 워터마크

영어 키워드:

random text, unreadable lettering,
misspelled text, unauthorized signage,
unauthorized brand logo, watermark.

허용된 정확한 간판은 4장 예외 규칙을 적용한다.

### 1.6 가독성 및 구성

- 대상이 무엇인지 식별하기 어려운 구성
- 메인 오브젝트가 다른 요소에 가려지는 구성
- 의미 전달을 방해하는 복잡한 디테일
- 불필요한 배경 요소로 인한 시각적 혼잡
- 주요 오브젝트의 실루엣이 사라지는 구성

영어 키워드:

low readability, unclear silhouette,
overly complex detail, cluttered background,
obscured main object.

### 1.7 카테고리별 필수 금지 요소

#### Place (건물 및 장소형)

- 사실적인 건축 렌더링 스타일
- 요청하지 않은 로고
- 장소를 오인하게 하는 대표 상징물
- 의미 없는 간판
- 파손된 건물 구조

#### Character

- 사실적인 피부 및 모공
- 사실적인 개별 머리카락 또는 털
- 명백하게 잘못된 손이나 신체 구조
- 의도하지 않은 추가 손가락 또는 팔다리
- 인종적 고정관념에 기반한 과장 표현

---

## 2. 가급적 회피

### 2.1 적용 원칙

회피 요소는 반드시 금지되는 오류와 구분한다.

대상의 의미 전달이나 사용자 요청에 필요한 경우 제한적으로 사용할 수 있다.

단, 사용으로 인해 기본 스타일 또는 인지성이 훼손되는 경우 수정이 필요하다.

### 2.2 조형 및 디테일

- 지나치게 얇고 불안정한 구조
- 과도한 곡률로 대상의 특징이 사라지는 표현
- 지나치게 복잡한 창문 및 출입구
- 불필요하게 많은 소품
- 동일한 크기의 상징물이 과도하게 나열되는 구성
- 유아용 장난감처럼 지나치게 과장된 비례
- 지나치게 사실적인 신체 및 건물 비례

영어 키워드:

thin fragile structures, excessive rounding,
excessive windows, unnecessary props,
overly childish proportions.

### 2.3 재질

- 과도한 유광 표면
- 강한 반사 하이라이트
- 과도한 반투명 표현
- 지나치게 무거운 금속 느낌
- 오브젝트 간 재질 체계의 불일치

영어 키워드:

excessive gloss, excessive reflections,
overly shiny surfaces, inconsistent materials.

### 2.4 컬러

- 모든 오브젝트에 동일한 단일 색상 적용
- 과도한 색상 개수
- 대상의 고유 색상을 무시하는 컬러 사용
- 의미 없이 높은 채도
- 부자연스러운 컬러 조명

영어 키워드:

excessive color variation, excessive saturation,
uncontrolled color lighting.

### 2.5 카메라 및 구도

- 완전 정면 시점
- 지나치게 높은 탑뷰
- 로우 앵글
- 광각 원근 왜곡
- 불필요하게 넓은 배경 공간
- 불균형한 시각적 무게
- 기존 에셋과 현저하게 다른 크기
- 대상의 의미 전달을 방해하는 비대칭 구성
- 의도하지 않은 부유 표현

영어 키워드:

extreme top-down view, extreme low angle,
wide-angle distortion, inconsistent perspective,
unbalanced composition, unintended floating objects.

### 2.6 조명

- 지나치게 강한 접지 그림자
- 극적인 역광
- 강한 컬러 조명
- 과도한 블룸
- 지나치게 어두운 면
- 에셋별 조명 방향의 불일치

영어 키워드:

harsh shadow, dramatic lighting,
strong backlight, excessive bloom,
inconsistent lighting.

### 2.7 카테고리별 회피 요소

| 카테고리 | 회피 요소 |
|---|---|
| Place | 지나치게 많은 창문, 복잡한 건물 구조, 주변 거리 장면 |
| Character | 과장된 표정, 지나치게 큰 눈, 불필요한 의상 디테일 |

---

## 3. Negative Prompt 기본 문구

### 3.1 공통 Negative Prompt

다음 문구를 기본으로 사용한다.

photorealistic, photorealistic texture,
rough texture, gritty surface, noisy material,
skin pores, realistic fur, realistic hair strands,
fabric weave, dirty concrete, realistic wood grain,
brushed metal, chrome reflection,
excessive glass refraction, excessive reflections,
harsh neon, dark cyberpunk, cluttered background,
random text, unreadable lettering, misspelled text,
unauthorized brand logo, watermark,
distorted shape, broken geometry,
unintended duplicated object, low readability,
overly complex detail, harsh shadow,
muddy colors, washed-out pastel,
inconsistent perspective, cropped main object,
unbalanced composition

### 3.2 간결한 Negative Prompt

입력 길이가 제한되거나 간결한 프롬프트가 필요한 경우 사용한다.

photorealistic, rough texture, gritty surface,
noisy material, realistic skin, realistic fur,
fabric weave, chrome reflection, harsh neon,
cyberpunk, clutter, random text, logos,
distorted shape, broken geometry, duplication,
low readability, complex detail, harsh shadows,
muddy colors, washed-out pastel

텍스트나 로고에 대한 예외 요청이 있는 경우
logos, text 등의 광범위한 금지어를 조정한다.

### 3.3 카테고리별 추가 Negative Prompt

공통 Negative Prompt에 해당 카테고리의 조건을 추가한다.

#### Place (건물 및 장소형)

realistic architecture, photorealistic building,
complex storefront, excessive windows,
crowded streets, unrelated props,
illegible signage, incorrect place symbols

#### Character

uncanny face, exaggerated facial features,
realistic skin pores, realistic hair strands,
distorted hands, extra fingers,
extra limbs, broken anatomy

### 3.4 Negative Prompt 작성 방식

1. 공통 금지 문구를 적용한다.
2. 해당 카테고리별 추가 문구를 적용한다.
3. 요청 대상과 무관한 조건을 정리한다.
4. 승인된 예외와 충돌하는 표현을 제거하거나 제한한다.
5. 중복 및 모호한 금지어를 정리한다.

모든 금지 키워드를 기계적으로 나열할 필요는 없다.

대상에 실질적으로 적용되는 금지 조건과
스타일 일관성에 필요한 조건을 우선한다.

### 3.5 도구별 적용

- Negative Prompt 전용 입력란이 있으면 해당 영역에 입력한다.
- 별도 입력란이 없으면 자연어 제약 조건으로 작성한다.
- 제외 파라미터는 현재 모델에서 지원하는 경우에만 사용한다.
- 지원하지 않는 파라미터를 임의로 추가하지 않는다.

자연어 예시:

Do not introduce photorealistic textures,
rough surfaces, unnecessary props,
random text, unauthorized logos,
or changes to the original geometry.

### 3.6 수정 요청의 Negative Prompt

수정 요청에서는 원본 스타일 유지와 요청 범위 제한을 우선한다.

예시:

Do not add, remove, redesign or reposition
any elements outside the requested modification.

Do not alter the original composition,
camera angle, lighting, material,
or object proportions unless explicitly requested.

요청된 변경 대상 자체를 금지하는 문구는 제거한다.

---

## 4. 예외

### 4.1 예외 적용 원칙

예외는 명확한 사용자 요청, 카테고리별 디자인 규칙,
또는 승인된 레퍼런스에 근거하여 적용한다.

예외는 필요한 속성에만 적용하며 다른 스타일 제약까지 해제하지 않는다.

예외 적용 시 해당 변경 범위와 이유를 명확히 기록한다.

### 4.2 간판 및 텍스트

기본적으로 이미지 내부 텍스트는 사용하지 않는다.

장소 인지에 반드시 필요한 경우 정확한 간판 1개를 허용한다.

긍정 프롬프트:

Include only one clean readable sign
with the exact text "[EXACT TEXT]".

Negative Prompt:

random text, misspelled signage,
additional lettering, unauthorized logos

이 경우 no text처럼 허용된 간판을 함께 금지하는 표현은 사용하지 않는다.

### 4.3 밝은 컬러

매우 옅은 하늘색, 순백색, 크림색,
밝은 바닐라색은 대상의 특성 또는 배경으로 사용할 수 있다.

washed-out pastel 금지는 흐리고 탁한 색으로 인해
대상의 인지성과 스타일이 저하되는 경우를 의미한다.

### 4.4 유리, 금속, 물 및 기타 재질

대상을 인지하는 데 필요한 유리, 금속,
물 등의 특징은 단순화된 형태로 표현할 수 있다.

은은한 반투명 효과나 제한적인 하이라이트는 허용한다.

복잡한 실사 반사, 굴절 및 표면 질감은 허용하지 않는다.

### 4.5 복수 오브젝트

여러 개의 동일 오브젝트, 여러 명의 캐릭터 등
의도된 반복은 허용한다.

unintended duplicated object 금지는
요청하지 않은 중복 생성 또는 구조 오류를 의미한다.

### 4.6 부유 표현

다음과 같이 목적이 분명한 부유 표현은 허용할 수 있다.

- 공중에 떠 있는 오브젝트 연출
- 사용자가 요청한 공중 배치 연출

의도하지 않은 부유 표현이나
접지되어야 하는 건물의 부유 표현은 회피한다.

### 4.7 카메라 및 구도 예외

사용자가 정면, 측면, 탑뷰, 상세 클로즈업 등
특정 시점을 요청한 경우 해당 시점을 적용할 수 있다.

기본 시점과 다르게 제작되었다는 사실을 명시한다.

카메라 예외가 조형, 재질, 컬러 등의
다른 스타일 제약을 해제하는 것은 아니다.

시점을 변경할 때는 `brand-style-guide.md` 5.2.1의 수평 시점 변경 기준(±22.5°, ±45°, 0°)을 참고한다.

### 4.8 배경 예외

- 일반 아이콘: 흰색 또는 매우 옅은 하늘색
- UI 납품 에셋: 투명 배경
- 다크 배경 비주얼: 어두운 단색 계열
- 사용자 요청: 명시된 배경

선택된 배경은 다른 배경 지시와 충돌하지 않아야 한다.

### 4.9 지정 요소 변경

프로젝트에서 지정한 포인트 컬러, 심볼 등 고유 요소는
일반적인 생성 요청에서 임의로 변경하지 않는다.

리디자인 등 명시적인 변경 요청은
기존 스타일 규칙을 변경하는 별도 작업으로 구분한다.

승인되지 않은 변경안을 기존 스타일의
정상적인 에셋으로 분류하지 않는다.
