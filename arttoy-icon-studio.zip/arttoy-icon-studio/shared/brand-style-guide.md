# 미니어처 아트토이 스타일 가이드

> 이 파일이 미니어처 아트토이 스타일의 **단일 출처(Single Source of Truth)**입니다.
> 스타일이 바뀌면 여기만 수정합니다.
> `arttoy-ic-prompt`는 이 파일을 기준으로 이미지 생성 및 수정 프롬프트를 작성합니다.
> `arttoy-ic-review`는 이 파일을 기준으로 이미지의 스타일 일관성을 판단합니다.
> 금지·회피 요소는 `negative-rules.md`, 검수 방법은 `review-checklist.md`를 참조합니다.
>
> Version: 1.0
> Status: 디자인 가이드 정리본
> 적용 범위: 범용 (프로젝트별 포인트 컬러는 4장에서 지정)

---

## 1. 스타일 정의 (아트토이)

### 1.1 핵심 정의

미니어처 아트토이 스타일은 현실의 사물, 장소, 행동, 캐릭터 등의 개념을 작고 부드러운 3D 오브젝트로 재해석하는 비주얼 디자인 시스템입니다.

실제 사물을 사실적으로 축소하는 것이 아니라, 대상의 핵심 특징을 추출하여 모바일 UI에서 쉽게 인지할 수 있는 프리미엄 3D 아트토이 형태로 표현합니다.

### 1.2 핵심 스타일 키워드

- Friendly
- Clean
- Smooth
- Rounded
- Compact
- Premium
- App-friendly
- High-readability
- Soft 3D miniature
- Soft toy-like aesthetics

### 1.3 디자인 우선순위

| 우선순위 | 원칙 | 설명 |
|---|---|---|
| P0 | Recognizable | 대상의 의미를 즉시 인지할 수 있어야 한다. |
| P0 | Consistent | 기존 에셋과 동일한 시각 언어를 유지한다. |
| P0 | Readable | 작은 모바일 UI에서도 형태가 명확해야 한다. |
| P1 | Friendly | 친근하고 부담 없는 인상을 전달한다. |
| P1 | Premium | 정돈된 제품 디자인 품질을 유지한다. |
| P2 | Playful | 적절한 미니어처 감성과 재미를 제공한다. |

P0 원칙은 시각적 장식이나 개별 이미지의 예술적 완성도보다 우선한다.

### 1.4 적용 범위

- 사물 및 상징 오브젝트 아이콘
- 건물 및 장소형 아이콘
- 행동 및 개념을 표현하는 아이콘
- 3D 캐릭터 일러스트

### 1.5 일관성 유지 원칙

서로 다른 대상이라도 동일한 디자인 시스템에서 제작한 것처럼 보여야 한다.

일관성은 단순히 동일한 컬러를 사용하는 것이 아니라 다음 속성을 공통으로 유지하는 것을 의미한다.

- 조형 언어
- 모서리의 부드러움
- 재질의 표현 방식
- 시각적 디테일 밀도
- 카메라 방향
- 조명 방향
- 그림자의 특성
- 시각적 크기 및 여백
- 전체적인 완성도

승인된 기준 이미지가 있다면 새로운 스타일을 임의로 해석하기보다 기준 이미지와의 일치 여부를 우선한다.

---

## 2. 조형

### 2.1 기본 조형 언어

| 속성 | 디자인 기준 |
|---|---|
| Geometry | 단순화된 원, 구, 원기둥, 둥근 박스 |
| Edge | 부드럽고 둥근 모서리 |
| Bevel | 자연스럽게 연결되는 곡면 |
| Thickness | 안정적인 두께감 |
| Proportion | 컴팩트한 미니어처 비례 |
| Silhouette | 대상이 쉽게 인지되는 명확한 외곽 형태 |
| Detail | 의미 전달에 필요한 최소한의 디테일 |

현실적인 구조와 비례보다 대상의 특징 및 작은 화면에서의 인지성을 우선한다.

모서리를 둥글게 처리하되, 대상의 고유한 실루엣이 사라질 정도로 과도하게 변형하지 않는다.

### 2.2 오브젝트 구성 원칙

하나의 아이콘에는 명확한 메인 오브젝트가 존재해야 한다.

기본 구성:

- 메인 오브젝트 1개
- 대표 상징물 1~2개
- 보조 디테일 1~2개

보조 요소는 메인 오브젝트의 의미를 설명하는 역할을 하며 시각적 경쟁을 일으키지 않아야 한다.

모든 오브젝트는 하나의 응집된 미니어처 구성으로 표현한다.

### 2.3 건물 및 장소형 아이콘 조형

건물 및 장소형 아이콘은 다음 구조를 기본으로 한다.

Main building + representative symbol objects + essential supporting details

- 메인 오브젝트(건물 또는 대표 환경)를 중심에 둔다.
- 장소 인지에 필요한 대표 상징물과 보조 요소만 선택하여 디테일 과다를 방지한다.
- 대표 상징물은 인지성을 위해 실제 비율보다 확대할 수 있다.
- 건물이 본질적인 요소가 아닌 장소는 대표 환경을 메인 오브젝트로 사용한다.

### 2.4 캐릭터 조형

- 부드럽고 둥근 얼굴 형태
- 단순한 얼굴 특징
- 자연스러운 미소
- 친근하고 온화한 표정
- 매끄러운 덩어리형 헤어 볼륨
- 컴팩트한 신체 비례
- 행동을 인지할 수 있는 자연스러운 자세
- 단순한 의상 및 액세서리

다양한 피부톤, 연령, 헤어스타일, 의상 및 신체적 특성을 자연스럽게 표현한다.

캐릭터의 얼굴이나 인종적 특징을 과장하지 않는다.

필수 프롬프트:

Rounded 3D character, simple facial features,
gentle natural smile, warm and approachable expression,
smooth sculpted hair volume, compact proportions.

### 2.5 조형 공통 프롬프트

Rounded geometry, compact proportions,
thick simplified shapes, smooth bevels,
clean recognizable silhouette.

---

## 3. 재질

### 3.1 기본 재질

기본 재질은 부드러운 무광 플라스틱 또는 클레이 계열이다.

- Smooth matte plastic
- Soft clay-like material
- Clean polished surface
- Subtle glossy highlight

매끄러운 표면과 부드러운 곡면을 유지한다.

곡면을 설명하기 위한 은은한 하이라이트는 허용하지만, 거울처럼 반사되는 표면이나 과도한 유광 처리는 지양한다.

### 3.2 현실 재질의 단순화

| 현실 재질 | 표현 방식 |
|---|---|
| 플라스틱 | 매끄러운 무광 플라스틱 |
| 유리 | 단순한 하늘색 또는 절제된 반투명 표면 |
| 금속 | 회색 또는 은색의 부드러운 토이 표면 |
| 나무 | 따뜻한 갈색의 매끄러운 표면 |
| 돌 | 단순화된 둥근 형태와 매끄러운 표면 |
| 벽돌 | 단순화된 블록 형태 및 고유 컬러 |
| 천 | 부드러운 곡면과 간결한 덩어리 |
| 피부 | 매끄러운 클레이 재질 |
| 머리카락 | 덩어리형 헤어 볼륨 |
| 털 | 부드러운 덩어리 형태 |
| 물 | 단순화된 푸른 곡면 |

각 재질의 특징은 유지하되 실제 물질의 미세한 표면 질감을 재현하지 않는다.

### 3.3 재질 공통 프롬프트

Smooth matte plastic, soft clay-like material,
clean polished surfaces, subtle glossy highlights,
simplified toy-like surface treatment.

구체적인 재질 금지 항목은 `negative-rules.md`를 참조한다.

---

## 4. 색상

### 4.1 기본 컬러

| 컬러명 | HEX | 용도 |
|---|---|---|
| Accent Color | [프로젝트별 지정] | 포인트 컬러, 주요 강조 요소 |
| Pure White | #FFFFFF | 일반 아이콘의 기본 생성 배경 |

포인트 컬러가 필요한 경우 프로젝트에 맞게 HEX 값을 지정한다. 지정되지 않았다면 포인트 컬러를 임의로 정하지 않고 대상 고유 색상 중심으로 구성한다.

### 4.2 컬러 사용 원칙

- 선명하고 깨끗하며 가시성이 높은 컬러를 사용한다.
- 오브젝트 간 색상 대비를 명확하게 유지한다.
- 포인트 컬러와 대상의 고유 컬러가 공존하도록 한다.
- 모든 오브젝트를 하나의 색으로 통일하지 않는다.
- 포인트 컬러는 주요 강조 요소로 사용한다.
- 지나치게 흐리거나 탁한 파스텔을 사용하지 않는다.
- 과도한 네온 컬러 및 발광을 피한다.
- 대상 인지에 중요한 고유 색상을 유지한다.

### 4.3 확장 컬러 권장 팔레트

다음은 권장 보조 팔레트다.

공식 컬러로 승인된 값은 아니며 실제 기준 에셋에 따라 조정할 수 있다.

| 컬러명 | 권장 HEX |
|---|---|
| Sky Blue | #72B7FF |
| Soft Ice | #EAF4FF |
| Fresh Green | #42C875 |
| Warm Yellow | #FFC94D |
| Coral Red | #FF6262 |
| Warm Orange | #FF963D |
| Neutral Gray | #DCE3EB |

하나의 일반 아이콘에 주요 컬러 2~3개와 중립색을 사용하는 것을 권장한다.

대상 인지에 필요한 추가 컬러는 허용한다.

### 4.4 컬러 공통 프롬프트

Vivid, clean, high-visibility colors,
controlled saturation, clear color contrast,
selective accent color ([ACCENT HEX]) highlights.

포인트 컬러가 지정되지 않은 경우 마지막 줄은 생략한다.

### 4.5 컬러 정확도

생성형 AI에 HEX 값을 입력하더라도 정확한 색상 재현이 보장되지 않는다.

지정 색상의 정확도가 중요한 에셋은 후처리 및 실제 UI 적용 과정에서 보정한다.

조명으로 발생하는 밝기 차이와 기본색 자체의 변경을 구분한다.

---

## 5. 구도

### 5.1 기본 카메라

- 3/4 isometric view
- Slightly top-down angle
- Minimal perspective distortion
- Consistent camera orientation

정면과 측면, 상단의 일부가 자연스럽게 드러나는 시점을 기본으로 한다.

건물 및 장소형 아이콘은 전면과 오른쪽 측면이 보이는 방향을 권장한다.

승인된 기준 이미지에 다른 방향이 적용되어 있다면 기준 이미지의 방향을 우선한다.

### 5.2 카메라 권장 수치

| 항목 | 권장값 |
|---|---|
| 수평 회전각 | 약 30~45도 |
| 하향 각도 | 약 20~30도 |
| 원근 표현 | 왜곡이 적은 정투영에 가까운 시점 |

위 수치는 제작 일관성을 위한 권장값이며 확정된 규격이 아니다.

생성형 AI의 isometric 표현을 엄밀한 수학적 정투영으로 제한하지 않는다.

실제 기준 이미지와의 시점 일치 여부를 우선한다.

### 5.3 오브젝트 배치

- 중앙 중심의 응집된 구성
- 명확한 시각적 위계
- 균형 잡힌 시각적 무게
- 일관된 시각적 크기
- 충분한 여백
- 전체 오브젝트가 프레임 안에 포함되는 구도

건물 및 장소형 아이콘의 대표 상징물이 건물에 가려지지 않도록 한다.

현실의 물리적 크기와 관계없이 동일한 UI 슬롯에서 유사한 시각적 존재감을 유지한다.

### 5.4 프레임 및 여백

권장 기준:

- 기본 캔버스 비율: 1:1
- 오브젝트 점유율: 가장 긴 축 기준 약 75~80%
- 안전 여백: 각 방향 약 10% 이상 목표
- 메인 오브젝트 잘림 방지
- 접지 그림자가 프레임 밖으로 잘리지 않도록 구성

점유율 및 여백은 승인된 레퍼런스에 따라 조정한다.

### 5.5 배경

일반 아이콘의 생성 및 검수 배경:

- 순백색 #FFFFFF
- 매우 옅은 하늘색 그라디언트

다크 배경이 필요한 비주얼:

- 요청 시 지정된 딥 네이비 등 어두운 단색 계열

UI에 직접 배치하는 아이콘의 납품용 배경은 8장 출력 사양을 따른다.

생성용 배경과 최종 납품 배경을 혼동하지 않는다.

### 5.6 텍스트 및 간판

기본적으로 이미지 내부에 텍스트와 로고를 넣지 않는다.

대상 인지가 어려운 경우에만 정확한 간판 텍스트 1개를 허용한다.

프롬프트에는 exact text를 명시한다.

Include only one clean, readable sign
with the exact text "[EXACT TEXT]".
No additional lettering, no random text, no brand logos.

정확한 문자가 생성되지 않으면 빈 간판을 생성한 뒤 디자인 툴에서 합성하는 방식을 권장한다.

### 5.7 구도 공통 프롬프트

3/4 isometric view, slightly top-down angle,
minimal perspective distortion, centered composition,
balanced visual weight, consistent object scale,
full object visible, generous negative space.

---

## 6. 조명

### 6.1 기본 조명

좌측 전방 상단의 부드러운 스튜디오 조명을 기본으로 한다.

Upper front-left soft studio lighting.

모든 일반 아이콘은 동일한 스튜디오 환경에서 렌더링한 것처럼 보여야 한다.

### 6.2 조명 구성

| 요소 | 디자인 기준 |
|---|---|
| Key Light | 좌측 전방 상단의 부드러운 주 조명 |
| Fill Light | 어두운 면을 완화하는 간접광 |
| Highlight | 곡면을 강조하는 은은한 하이라이트 |
| Ambient Occlusion | 오브젝트 접합부의 약한 음영 |
| Contact Shadow | 바닥과의 접지를 표현하는 부드러운 그림자 |
| Contrast | 형태가 명확하게 인지되는 적절한 명암 |
| Color Temperature | 중립적인 색온도 |

### 6.3 그림자

- 부드러운 접지 그림자를 사용한다.
- 그림자가 오브젝트보다 강하게 보이지 않도록 한다.
- 주 조명 방향과 그림자 방향이 자연스럽게 일치해야 한다.
- 검고 강한 그림자를 사용하지 않는다.
- 인위적인 부유감을 방지한다.

오브젝트가 떠 있는 연출 등 의도된 구성은 예외로 적용할 수 있다.

### 6.4 조명 예외

사용자가 명시적으로 다른 조명 연출을 요청한 경우에는 기본 스타일에서 변경되는 부분을 구분한다.

### 6.5 조명 공통 프롬프트

Soft studio lighting from the upper front-left,
gentle fill light, subtle ambient occlusion,
soft contact shadow, balanced highlights,
neutral lighting.

---

## 7. 프롬프트 작성 규칙

### 7.1 기본 원칙

프롬프트 작성 시 변경 가능한 대상별 요소와 공통 디자인 스타일을 분리한다.

고정 스타일은 매번 새롭게 해석하지 않는다.

사용자가 대상만 입력하더라도 이 파일의 기본값을 적용한다.

누락된 정보가 결과물에 실질적인 영향을 주지 않는 경우 합리적인 기본값으로 완성한다.

### 7.2 프롬프트 구조

다음 순서로 작성한다.

1. Subject and Purpose
2. Object Composition
3. Shape Language
4. Material
5. Color
6. Camera
7. Lighting
8. Composition and Background
9. Output Quality
10. Negative Constraints

### 7.3 공통 프롬프트 토큰

프롬프트 토큰은 반복 사용되는 디자인 조건을 일관되게 유지하기 위한 관리 단위다.

#### STYLE_BASE

Premium soft 3D miniature icon,
friendly art toy aesthetics,
clean, modern, playful yet premium.

#### SHAPE_BASE

Rounded geometry, compact proportions,
thick simplified shapes, smooth bevels,
clean recognizable silhouette.

#### MATERIAL_BASE

Smooth matte plastic, soft clay-like material,
clean polished surfaces, subtle glossy highlights.

#### COLOR_BASE

Vivid, clean, high-visibility colors,
controlled saturation, clear color contrast,
selective accent color ([ACCENT HEX]) highlights.

#### CAMERA_BASE

3/4 isometric view, slightly top-down angle,
consistent camera orientation,
minimal perspective distortion.

#### LIGHT_BASE

Soft studio lighting from the upper front-left,
gentle fill light, subtle ambient occlusion,
soft contact shadow.

#### COMPOSITION_BASE

Centered composition, balanced visual weight,
consistent object scale, full object visible,
generous negative space.

#### BG_LIGHT

Isolated on a pure white background (#FFFFFF),
square 1:1 composition.

#### BG_DARK

Clean deep dark background ([DARK HEX]),
controlled contrast, minimal visual noise.

#### BG_TRANSPARENT

Isolated object on a transparent background,
clean alpha edges, no visible background plane.

#### QUALITY_BASE

Polished mobile app asset quality,
cohesive visual system,
high readability at small icon sizes.

#### TEXT_NONE

No text, no random lettering, no brand logos.

#### TEXT_EXACT

Include only one clean readable sign
with the exact text "[EXACT TEXT]".
No additional lettering, no brand logos.

### 7.4 고정 및 변경 토큰

| 모듈 | 관리 방식 |
|---|---|
| STYLE_BASE | 고정 |
| SHAPE_BASE | 고정 |
| MATERIAL_BASE | 고정 |
| COLOR_BASE | 포인트 컬러 고정, 대상 컬러 변경 |
| CAMERA_BASE | 기본 고정, 목적에 따른 예외 허용 |
| LIGHT_BASE | 기본 고정, 카테고리 예외 허용 |
| COMPOSITION_BASE | 기본 원칙 고정 |
| BG_LIGHT / BG_DARK / BG_TRANSPARENT | 목적에 따라 선택 |
| QUALITY_BASE | 고정 |
| TEXT_NONE / TEXT_EXACT | 필요에 따라 선택 |

실제 사용자에게 출력하는 프롬프트에는 토큰명이 아닌 완성된 영어 문장을 제공한다.

배경 토큰을 서로 충돌하게 사용하지 않는다.

### 7.5 메인 프롬프트 템플릿

Create a premium soft 3D miniature [ASSET TYPE]
representing [SUBJECT].

The main object is [MAIN OBJECT], supported by
[PRIMARY SYMBOL OBJECTS] and [SUPPORTING DETAILS].

Use friendly art toy aesthetics, rounded geometry,
compact proportions, thick simplified shapes,
smooth bevels, and a clean recognizable silhouette.

Smooth matte plastic, soft clay-like materials,
clean polished surfaces, subtle glossy highlights.

Use [SUBJECT-SPECIFIC COLORS] with selective
accent color ([ACCENT HEX]) highlights.
Vivid, clean, high-visibility colors.

3/4 isometric view, slightly top-down angle,
minimal perspective distortion.
Soft studio lighting from the upper front-left,
subtle ambient occlusion and soft contact shadow.

Centered composition, balanced visual weight,
consistent object scale, full object visible,
generous negative space.

[BACKGROUND AND ASPECT RATIO]

Polished mobile app asset quality,
high readability at small icon sizes,
cohesive 3D visual identity.

[TEXT AND CATEGORY-SPECIFIC CONSTRAINTS]

### 7.6 짧은 실전형 프롬프트

Soft 3D miniature [SUBJECT] with [KEY OBJECTS],
friendly art toy style, rounded geometry,
compact proportions, smooth matte plastic,
vivid clean colors, [ACCENT HEX] accents,
3/4 isometric view, slightly top-down angle,
soft upper front-left studio lighting,
subtle ambient occlusion, soft contact shadow,
centered composition, [BACKGROUND],
premium mobile app asset, high readability,
[CATEGORY-SPECIFIC CONSTRAINTS].

짧은 프롬프트에서도 대상, 조형, 재질, 컬러,
카메라, 조명, 배경, 가독성 조건을 유지한다.

### 7.7 레퍼런스 기반 생성 프롬프트

승인된 기준 이미지가 제공된 경우 사용한다.

Use the provided approved reference image
as the primary visual style guide.

Match its rounded geometry, compact proportions,
bevel softness, matte plastic material,
color saturation, camera angle, lighting direction,
shadow softness, object scale and visual quality.

Create a new [SUBJECT] using the same
visual design language.

Change the subject and necessary representative
objects while preserving the reference image's
visual style.

The new asset should look as if it belongs to
the same original 3D icon collection.

레퍼런스 이미지가 실제로 제공되지 않은 경우
해당 이미지가 첨부되었다고 가정하지 않는다.

### 7.8 수정 프롬프트

수정 요청에서는 변경 요소와 유지 요소를 구분한다.

Preserve all existing elements except [TARGET ELEMENT].

Only modify [TARGET ELEMENT] by [REQUESTED CHANGE].

Do not change the composition, color palette,
camera angle, lighting, object scale,
object placement, or background unless requested.

Maintain the original 3D visual style.

The result should appear to be the same original
asset with only the requested modification applied.

요청한 변경 속성은 유지 조건에서 제외한다.

예를 들어 배경을 변경하는 요청에는 배경 유지 조건을 포함하지 않는다.

수정 과정에서 다른 오브젝트를 추가하거나 삭제하지 않는다.

### 7.9 생성 도구별 작성 방식

| 도구 | 작성 방식 |
|---|---|
| ChatGPT 이미지 생성 | 자연어 지시형, 레퍼런스 기반 생성 및 수정 범위 명시 |
| Midjourney | 압축된 시각 키워드, 지원되는 비율 및 제외 파라미터 활용 |
| Freepik | 간결하고 직접적인 오브젝트 및 스타일 묘사 |
| Magnific | 기존 구조 유지, 요청된 개선 범위 및 디테일 제한 |

도구별 입력 방식은 조정할 수 있지만 이 파일의 시각적 규칙은 유지한다.

모델 버전에 따라 달라지는 파라미터를 고정 규칙으로 사용하지 않는다.

지원 여부가 확인되지 않은 파라미터를 임의로 생성하지 않는다.

Negative Prompt 전용 입력란이 없는 경우 긍정형 프롬프트의 마지막에 자연어 제약 조건으로 작성한다.

### 7.10 Negative Prompt

공통 및 카테고리별 금지 요소는 `negative-rules.md`를 참조한다.

Negative Prompt를 작성하기 전에 허용되는 간판, 발광 효과 등과 충돌하는 조건이 없는지 확인한다.

### 7.11 프롬프트 생성기 출력 형식

기본 응답 순서:

1. 콘셉트 요약
2. 핵심 오브젝트 구성
3. 메인 프롬프트
4. 짧은 실전형 프롬프트
5. Negative Prompt
6. 유지해야 할 요소
7. 주의해야 할 실패 요소

설명은 한국어로 작성한다.

이미지 생성 프롬프트는 기본적으로 영어로 작성한다.

사용자가 프롬프트만 요청한 경우 해당 프롬프트를 중심으로 간결하게 제공한다.

### 7.12 프롬프트 출력 전 검토

- 생성 대상과 목적이 명확한가?
- 대상별 필수 상징물이 포함되어 있는가?
- 공통 스타일 토큰이 누락되지 않았는가?
- 오브젝트 개수가 과도하지 않은가?
- 카메라와 조명이 일관적인가?
- 텍스트 규칙을 충족하는가?
- 긍정 프롬프트와 Negative Prompt가 충돌하지 않는가?
- 수정 요청의 범위를 임의로 확장하지 않았는가?

---

## 8. 출력 사양

### 8.1 기본 출력 사양

| 항목 | 기준 |
|---|---|
| 파일 형식 | PNG / WebP |
| 기본 원본 해상도 | 1024×1024px |
| 기본 비율 | 1:1 |
| UI 아이콘 납품 배경 | 투명 |
| 기본 재질 | 매트 플라스틱 또는 소프트 클레이 |
| 기본 스타일 | 단순한 3D 미니어처 아트토이 |

### 8.2 생성 배경과 납품 배경의 구분

UI 아이콘 납품 에셋은 투명 배경을 사용한다.

일반 아이콘의 생성 및 검수 배경으로는 순백색 또는 매우 옅은 하늘색 배경을 사용한다.

이를 다음과 같이 운영하는 것을 권장한다.

- 생성 및 스타일 검수: 흰색 배경
- UI 아이콘 최종 납품: 투명 배경
- 다크 배경 일러스트: 어두운 배경 유지 가능

흰색 배경은 투명 배경과 동일하지 않다.

투명 배경 납품 시 실제 알파 채널 존재 여부를 확인한다.

배경 제거 과정에서 오브젝트의 가장자리와 접지 그림자가 손상되지 않도록 한다.

사용자가 특정 배경을 명시한 경우 해당 요청을 우선한다.

### 8.3 해상도 및 실제 UI 검수

| 규격 | 용도 |
|---|---|
| 1024×1024px | 기본 마스터 이미지 |
| 512×512px | 고해상도 활용 |
| 256×256px | 일반 앱 이미지 |
| 128×128px | 소형 앱 이미지 |
| 32 / 48 / 64px | 실제 UI 가독성 검수 |

위 파생 해상도는 권장값이다.

모든 크기의 파일을 별도로 제작할 필요는 없으며 실제 UI 표시 크기 및 디바이스 배율에 따라 결정한다.

### 8.4 파일 관리

권장 파일명:

[PROJECT]_[CATEGORY]_[SUBJECT]_[VARIANT]_[VERSION]_[SIZE].[EXT]

예시:

Project_Object_Sample_Default_v01_1024.png
Project_Character_Sample_Single_v01_1024.webp

최종 에셋과 함께 다음 정보를 저장하는 것을 권장한다.

- 사용한 프롬프트
- Negative Prompt
- 기준 레퍼런스 ID
- 생성 도구 및 모델 버전
- 지원되는 경우 Seed 및 Reference Strength
- 수정 이력
- 승인 상태
- 디자인 가이드 버전

승인된 에셋을 수정할 때는 기존 파일을 덮어쓰지 않고 새로운 버전을 생성한다.

---

## 9. 레퍼런스 이미지

기준 이미지는 `reference-images/`에 두고,
이미지별 설명은 해당 폴더의 `README.md`에 기록합니다.

### 9.1 Golden Reference 정의

Golden Reference는 카테고리별로 승인된 기준 에셋을 의미한다.

신규 에셋의 스타일 및 시각적 일관성은 Golden Reference를 기준으로 판단한다.

### 9.2 권장 기준 이미지 구성

| Reference ID | 카테고리 | 기준 대상 |
|---|---|---|
| REF-OBJECT-001 | Object | 기본 사물 |
| REF-PLACE-001 | Place | 건물 및 장소형 |
| REF-CHAR-001 | Character | 기본 캐릭터 |

위 ID는 권장 관리 체계다.

실제로 존재하거나 승인된 이미지 목록을 의미하지 않는다.

### 9.3 README 기록 항목

- Reference ID
- 파일명
- 카테고리
- 이미지 설명
- 승인 상태
- 고정해야 할 스타일 특성
- 조형 특성
- 재질 특성
- 컬러 특성
- 카메라 방향
- 조명 방향
- 그림자 특성
- 해당 이미지에 사용된 프롬프트
- 생성 환경
- 버전
- 승인일

### 9.4 레퍼런스 적용 규칙

- 동일 카테고리의 승인된 이미지를 우선 사용한다.
- 신규 에셋과 기존 에셋을 나란히 비교한다.
- 오브젝트 종류보다 형태, 재질, 시점, 조명, 디테일 밀도의 일치 여부를 판단한다.
- 승인되지 않은 시안을 기준 이미지로 간주하지 않는다.
- 기존 기준 이미지를 변경하면 버전 및 변경 사유를 기록한다.

### 9.5 기준 이미지가 없는 경우

이 파일의 텍스트 디자인 규칙을 적용한다.

실제 레퍼런스가 없는 상황에서 기존 에셋과 완전히 동일하다고 판단하지 않는다.

레퍼런스 비교가 필요한 항목은 검수 시 판단 불가로 처리한다.

### 9.6 기준 충돌 처리

승인된 레퍼런스와 이 파일의 명시적 스타일 규칙이 충돌하는 경우 임의로 어느 한쪽을 변경하지 않는다.

충돌 내용을 디자이너에게 전달한다.

최종 승인된 결정은 이 파일에 반영하여 단일 출처를 유지한다.
